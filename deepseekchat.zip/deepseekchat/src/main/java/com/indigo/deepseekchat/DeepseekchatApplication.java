package com.indigo.deepseekchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeepseekchatApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeepseekchatApplication.class, args);
	}

}
