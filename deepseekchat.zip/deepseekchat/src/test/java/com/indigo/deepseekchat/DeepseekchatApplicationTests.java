package com.indigo.deepseekchat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeepseekchatApplicationTests {

	@Test
	void contextLoads() {
	}

}
